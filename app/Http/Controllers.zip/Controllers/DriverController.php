<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Cabang;
use App\Models\Driver;
use App\Models\Kendaraan;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DriverController extends Controller
{
    public function index(Request $request)
    {
        $query = Driver::with(['kendaraan', 'cabang']);

        if ($search = $request->get('search')) {
            $query->where(function ($sub) use ($search) {
                $sub->where('driver_code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('vehicle_type', 'like', "%{$search}%")
                    ->orWhere('assigned_route', 'like', "%{$search}%")
                    ->orWhereHas('kendaraan', function ($q) use ($search) {
                        $q->where('kode_kendaraan', 'like', "%{$search}%")
                          ->orWhere('nama_kendaraan', 'like', "%{$search}%");
                    })
                    ->orWhereHas('cabang', function ($q) use ($search) {
                        $q->where('nama_cabang', 'like', "%{$search}%");
                    });
            });
        }

        if ($status = $request->get('status')) {
            $query->where('status', $status);
        }

        $drivers = $query->orderBy('created_at', 'desc')
            ->paginate(10)
            ->withQueryString();

        return view('armada.drivers.index', compact('drivers'));
    }

    public function create()
    {
        $kendaraans = Kendaraan::orderBy('kode_kendaraan')->get();
        $cabangs = Cabang::orderBy('nama_cabang')->get();

        return view('armada.drivers.create', compact('kendaraans', 'cabangs'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:50',
            'kendaraan_id' => ['required', Rule::exists('kendaraan', 'id')],
            'cabang_id' => ['required', Rule::exists('cabang', 'id')],
            'license_class' => ['required', Rule::in(Driver::licenseClasses())],
            'license_expiry_date' => 'required|date',
            'status' => ['required', Rule::in(Driver::statuses())],
            'notes' => 'nullable|string|max:1000',
        ]);

        $kendaraan = Kendaraan::findOrFail($data['kendaraan_id']);
        $cabang = Cabang::findOrFail($data['cabang_id']);

        Driver::create([
            'driver_code' => Driver::generateCode(),
            'name' => $data['name'],
            'phone' => $data['phone'],
            'kendaraan_id' => $data['kendaraan_id'],
            'vehicle_type' => $kendaraan->kode_kendaraan . ' - ' . $kendaraan->nama_kendaraan,
            'license_class' => $data['license_class'],
            'license_expiry_date' => $data['license_expiry_date'],
            'cabang_id' => $data['cabang_id'],
            'assigned_route' => $cabang->nama_cabang,
            'status' => $data['status'],
            'notes' => $data['notes'] ?? null,
        ]);

        return redirect()->route('armada.drivers.index')
            ->with('success', 'Driver armada berhasil ditambahkan.');
    }

    public function show(Driver $driver)
    {
        return view('armada.drivers.show', compact('driver'));
    }

    public function edit(Driver $driver)
    {
        $kendaraans = Kendaraan::orderBy('kode_kendaraan')->get();
        $cabangs = Cabang::orderBy('nama_cabang')->get();

        return view('armada.drivers.edit', compact('driver', 'kendaraans', 'cabangs'));
    }

    public function update(Request $request, Driver $driver)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:50',
            'kendaraan_id' => ['required', Rule::exists('kendaraan', 'id')],
            'cabang_id' => ['required', Rule::exists('cabang', 'id')],
            'license_class' => ['required', Rule::in(Driver::licenseClasses())],
            'license_expiry_date' => 'required|date',
            'status' => ['required', Rule::in(Driver::statuses())],
            'notes' => 'nullable|string|max:1000',
        ]);

        $kendaraan = Kendaraan::findOrFail($data['kendaraan_id']);
        $cabang = Cabang::findOrFail($data['cabang_id']);

        $driver->update([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'kendaraan_id' => $data['kendaraan_id'],
            'vehicle_type' => $kendaraan->kode_kendaraan . ' - ' . $kendaraan->nama_kendaraan,
            'license_class' => $data['license_class'],
            'license_expiry_date' => $data['license_expiry_date'],
            'cabang_id' => $data['cabang_id'],
            'assigned_route' => $cabang->nama_cabang,
            'status' => $data['status'],
            'notes' => $data['notes'] ?? null,
        ]);

        return redirect()->route('armada.drivers.index')
            ->with('success', 'Data driver berhasil diperbarui.');
    }

    public function destroy(Driver $driver)
    {
        $driver->delete();

        return redirect()->route('armada.drivers.index')
            ->with('success', 'Driver armada berhasil dihapus.');
    }
}
